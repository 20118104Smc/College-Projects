void setup()
{
size(500,400);
background(255,255,255);
}

void draw()
{
fill(255,0,0);
noStroke();
rect(100,50,100,100);

fill(0,255,0);
rect(220,50,100,100);

fill( 0, 161, 241);
rect(100,170,100,100);

fill(255,195,0);
rect(220,170,100,100);
}
