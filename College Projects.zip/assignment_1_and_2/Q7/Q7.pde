void setup()
{
size(500,400);
background(255);
}

void draw()
{
fill(255);
ellipse(250,100,100,100);

fill(0);
ellipse(215,100,25,55);
ellipse(286,100,25,55);

fill(180);
rect(225,150,50,170);

line(225,320,200,355);
line(275,320,290,355);
}
