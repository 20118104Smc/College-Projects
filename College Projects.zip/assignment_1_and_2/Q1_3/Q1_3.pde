void setup()
{
size(500,400);
}

void draw()
{
//Q1a
  //full white rect
//fill(255,255,255); 
//rect(40,40,200,200);

// slightly grey rect
//fill(200,200,200);
//rect(90,90,200,200);

// dark grey rect
//fill(100,100,100);
//rect(140,140,200,200);

// darkest rect
//fill(50,50,50);
//rect(190,190,200,200);


//Q1B
//fill(255,255,255);
//rect(100,50,150,150);

  //lines that make first clear square
//line(120,70,120,220);
//line(120,220,270,220);
//line(270,220,270,70);
//line(120,70,270,70);

  //lines that make second clear square
//line(140,90,140,240);
//line(140,240,290,240);
//line(140,90,290,90);
//line(290,90,290,240);

// top line
//line(100,50,400,50);


// middle line
//fill(0,0,0);
//strokeWeight(5);
//rect(80,100,340,50);
//ellipse(80,125,50,50);
//ellipse(425,125,50,50);

// thick line
//rect(60,175,385,100);
//ellipse(60,225,100,100);
//ellipse(440,225,100,100);
int age;
age = 21;

float tall_or_short;
tall_or_short = 1.89;

String inital;
inital = "S";

boolean exams;
exams = true;
println(age);
println(tall_or_short);
println(inital);
print(exams);
}
