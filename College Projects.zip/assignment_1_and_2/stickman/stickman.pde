void setup()
{
size(500,500);
background(260,250,250);

}
void draw(){
ellipse(250,150,80,80);
line(250,190,250,350);
line(180,250,250,280);
line(250,280,320,250);
line(250,350,200,390);
line(250,350,300,390);
}

void
