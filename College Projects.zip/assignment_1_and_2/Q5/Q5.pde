size(200,200);

float xCoordinate;
float yCoordinate;

xCoordinate = 50.67;
yCoordinate = 100.33;

rect(xCoordinate, xCoordinate, 80, 80);
