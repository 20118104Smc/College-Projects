void setup()
{
size(500,400);
background(255,255,255);
}

void draw()
{
fill(255,0,0);
noStroke();
ellipse(250,200,250,250);

fill(255,255,255);
ellipse(250,200,140,140);

fill(255,0,0);
ellipse(250,200,80,80);

fill(255,255,255);
rect(180,50,29,160);
}
