//Q4
void setup()
{
size(300,400);
background(0);
stroke(0,100,255);
strokeWeight(6);

int a = 70;
int b = 12;
int c = 230;


line(a, b, c, b);
line(a, b+20, c, b+20);
line(a, b+40, c, b+40);

line(a, b+90, c, b+90);
line(a, b+90, c, b+110);
line(a, b+110, c, b+110);
}
