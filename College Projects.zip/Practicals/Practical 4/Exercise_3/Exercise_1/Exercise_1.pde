void setup()
{
  size(500,400);
  background(0);
}

void draw()
{


if(mousePressed == true)
{
stroke(60);
fill(255,0,0);
stroke(60);
ellipse(mouseX, mouseY,100,100);
}
else
{
background(0);
}
}
