void setup()
{
size(500,400);
background(0);
}
int mouseHeight = 100;
int mouseWidth = 100;

void draw()
{
ellipse(mouseX,mouseY,mouseHeight,mouseWidth);

if(mousePressed == true && mouseHeight >50 && mouseWidth >50)
{
mouseHeight = mouseHeight - 10;
mouseWidth = mouseWidth - 10;
}
}
