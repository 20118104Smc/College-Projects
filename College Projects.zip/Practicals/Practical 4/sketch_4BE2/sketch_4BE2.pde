void setup()
{
size(500,500);
background(0);
}


int ballHeight = 450;
void draw()
{
background(0);
fill(0,255,0);
ellipse(250,ballHeight,100,100);

if(keyPressed && key == 'U' || key== 'u') // if u or U are pressed the ball will go up 
{



ballHeight = ballHeight - 1;
ellipse(250,ballHeight,100,100);

}


if(keyPressed && key == 'D' || key== 'd')
{
  
ballHeight = ballHeight  +1;
ellipse(250,ballHeight,100,100); // makes ball go down 

}
}
