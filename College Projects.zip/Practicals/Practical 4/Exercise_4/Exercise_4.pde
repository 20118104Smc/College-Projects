void setup()
{
size(500,500);
}

float colour = 255;
float colour2 = 50;
float  colour3 = 50;
void draw()
{


if(mousePressed)
{
colour = colour -1;
colour2 = colour +3;
colour3 = colour +5;

fill(colour,colour2,colour3);
ellipse(mouseX,mouseY,50,50);
}

if(colour == 0)
{
colour = 255;
}

if(colour2 == 0)
{
colour = 255;
}

if(colour3 == 0)
{
colour = 255;
}
}
